/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50096
Source Host           : localhost:3306
Source Database       : student_grade_manage

Target Server Type    : MYSQL
Target Server Version : 50096
File Encoding         : 65001

Date: 2015-05-26 22:54:22
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `grades`
-- ----------------------------
DROP TABLE IF EXISTS `grades`;
CREATE TABLE `grades` (
  `studentNum` varchar(20) NOT NULL,
  `math` varchar(10) NOT NULL,
  `english` varchar(10) NOT NULL,
  `JAVA` varchar(10) NOT NULL,
  `ComputerNetwork` varchar(10) NOT NULL,
  PRIMARY KEY  (`studentNum`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of grades
-- ----------------------------
INSERT INTO `grades` VALUES ('131110101', '5', '6', '7', '8');
INSERT INTO `grades` VALUES ('131110102', '7', '8', '9', '10');

-- ----------------------------
-- Table structure for `student_information`
-- ----------------------------
DROP TABLE IF EXISTS `student_information`;
CREATE TABLE `student_information` (
  `studentNum` varchar(20) NOT NULL,
  `studentName` varchar(20) NOT NULL,
  `studentClass` varchar(20) NOT NULL,
  PRIMARY KEY  (`studentNum`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of student_information
-- ----------------------------
INSERT INTO `student_information` VALUES ('131110101', '张三', '1311101');
INSERT INTO `student_information` VALUES ('131110102', '李四', '1311101');
