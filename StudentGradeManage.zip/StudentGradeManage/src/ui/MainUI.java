package ui;

import javax.swing.JFrame;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import DAO.Grades;
import DAO.StudentInformation;
import service.MainUIService;

public class MainUI extends JFrame implements ActionListener, MouseListener{
	private JPanel contentPane;
	private JTextField tf_find;
	private JTable table;
	private JComboBox cb_find;
	private JComboBox cb_show;
	private JButton b_change;
	private JButton b_ex;
	private JButton b_cancel;
	//private ManagerService managerService = new ManagerService();
	private String studentNum;
	private String studentName;
	private String classNum;
	private String mathGrade;
	private String englishGrade;
	private String JAVAGrade;
	private String networkGrade;
	private double totalGrade;
	private double average;
	private String s[] = {"ѧ��","����","�༶","��ѧ","Ӣ��","java","����","�ܷ�","ƽ����"};
	private final DefaultTableModel dtm;
	
	private List<Grades> grades;
	
	private MainUIService service = new MainUIService();
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainUI frame = new MainUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}
	
	public MainUI() {
		setTitle("ѧ���ɼ�����");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//final DefaultTableModel dtm = (DefaultTableModel) tabel
		//table.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(10, 190, 764, 336);
		//scrollPane.setLayout(null);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel());
		scrollPane.setViewportView(table);
		table.addMouseListener(this);
		
		dtm = (DefaultTableModel) table.getModel();
		dtm.setColumnIdentifiers(s);
		
		//ˢ�º���
		update();
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 34, 764, 84);
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		b_change = new JButton("������Ϣ");
		b_change.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					new AddInformation().setVisible(true);
				
			}
		});
		b_change.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		b_change.setBounds(94, 10,  105, 60);
		panel.add(b_change);
		
		b_ex = new JButton("�޸���Ϣ");
		//
		b_ex.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int index = table.getSelectedRow();
				
				if (index == -1)
				{
					JOptionPane.showMessageDialog(null, "��ѡ��һ����Ϣ", "��ʾ", JOptionPane.YES_OPTION);
				}
				else
				{
					String num = (String) dtm.getValueAt(index, 0);
					new ChangeGrade(num).setVisible(true);
				}
			}
		});



		b_ex.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		b_ex.setBounds(341, 10, 93, 60);
		panel.add(b_ex);
		
		b_cancel = new JButton("ɾ����Ϣ");
		b_cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int index = table.getSelectedRow();
				if (index == -1)
				{
					JOptionPane.showMessageDialog(null, "��ѡ��һ����Ϣ", "��ʾ", JOptionPane.YES_OPTION);
				}
				else
				{
					String num = (String) dtm.getValueAt(index, 0);
					if(service.delete(num))
					{
						update();
					    JOptionPane.showMessageDialog(null,"ɾ����Ϣ�ɹ�","��ʾ",JOptionPane.OK_CANCEL_OPTION);
					}
					else
					{
						JOptionPane.showMessageDialog(null,"ɾ����Ϣʧ��","��ʾ",JOptionPane.OK_CANCEL_OPTION);
					}
						
				}
			}
		});
		b_cancel.setBounds(558, 10, 99, 60);
		panel.add(b_cancel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 128, 764, 52);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton_3 = new JButton("����");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int type = cb_find.getSelectedIndex();
				switch (type) {
					case 1:
					{
						try {
						    String check_stuNum = tf_find.getText();
						    StudentInformation info = service.getStuInfoByid(check_stuNum);
						    Grades gra = service.getGradeById(check_stuNum);
						
							Clear();
							tf_find.setText("");
							
							
							studentNum = gra.getStudentNum();
							studentName = info.getStudentName();
							classNum = info.getStudentClass();
							mathGrade = gra.getMath();
							englishGrade = gra.getEnglish();
							JAVAGrade = gra.getJava();
							networkGrade = gra.getComputerNetwork();
							totalGrade = Integer.parseInt(mathGrade)+Integer.parseInt(englishGrade)+Integer.parseInt(JAVAGrade)+Integer.parseInt(networkGrade);
							average = totalGrade/4;
							
							String sum = String.valueOf(totalGrade);
							String aver = String.valueOf(average);
							String sd[] = {studentNum,studentName,classNum,mathGrade,englishGrade,JAVAGrade,networkGrade,sum,aver};
							Vector temp = new Vector();
							for (int j = 0; j < sd.length; j++)
							{
								temp.add(sd[j]);
							}	
							dtm.addRow(temp);
						} catch (Exception e2) {
							// TODO: handle exception
							Clear();
							tf_find.setText("");
							update();
							JOptionPane.showMessageDialog(null,"û�и�ѧ��","��ʾ",JOptionPane.YES_OPTION);
						}
						
						break;
					}
					case 2:
					{
						try {
							String check_stuName = tf_find.getText();
							List<StudentInformation> infoList = service.getStuInfoByName(check_stuName);


							Clear();
							tf_find.setText("");
							
							Iterator<StudentInformation> it = infoList.iterator();
							while (it.hasNext()) {
								StudentInformation tempInfo = (StudentInformation)it.next();
								
								studentNum = tempInfo.getStudentNum();
								Grades tempGrade = service.getGradeById(studentNum);
								studentName = tempInfo.getStudentName();
								classNum = tempInfo.getStudentClass();
								mathGrade = tempGrade.getMath();
								englishGrade = tempGrade.getEnglish();
								JAVAGrade = tempGrade.getJava();
								networkGrade = tempGrade.getComputerNetwork();
								totalGrade = Integer.parseInt(mathGrade)+Integer.parseInt(englishGrade)+Integer.parseInt(JAVAGrade)+Integer.parseInt(networkGrade);
								average = totalGrade/4;
								
								String sum = String.valueOf(totalGrade);
								String aver = String.valueOf(average);
								
								String sd[] = {studentNum,studentName,classNum,mathGrade,englishGrade,JAVAGrade,networkGrade,sum,aver};
								Vector temp = new Vector();
								for (int j = 0; j < sd.length; j++)
								{
									temp.add(sd[j]);
								}	
								dtm.addRow(temp);
							
							}
							
						} catch (Exception e2) {
							// TODO: handle exception
							Clear();
							tf_find.setText("");
							update();
							JOptionPane.showMessageDialog(null,"û�и�ѧ��","��ʾ",JOptionPane.YES_OPTION);
						}
						break;
					}

					case 0:
						update();
						break;
					default:
						break;
					}
			}
		});
		btnNewButton_3.setBounds(337, 17, 60, 25);
		panel_1.add(btnNewButton_3);
		btnNewButton_3.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		
		JButton button_6 = new JButton("ˢ��");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Clear();
				update();
			}
		});
		button_6.setBounds(619, 18, 93, 23);
		panel_1.add(button_6);
		
		tf_find = new JTextField();
		tf_find.setBounds(186, 19, 126, 21);
		panel_1.add(tf_find);
		tf_find.setColumns(10);
		
/*		cb_show = new JComboBox();
		cb_show.setModel(new DefaultComboBoxModel(new String[] {"����������", "ѧ��", "ƽ����"}));
		cb_show.setBounds(521, 19, 88, 21);
		panel_1.add(cb_show);
		cb_show.addActionListener(this);
		
		JButton button_6 = new JButton("����");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Clear();
				update();
			}
		});
		button_6.setBounds(619, 18, 93, 23);
		panel_1.add(button_6);*/
		
		cb_find = new JComboBox();
		cb_find.setModel(new DefaultComboBoxModel(new String[] {"�����²�ѯ", "ѧ��", "����"}));
		cb_find.setBounds(44, 19, 111, 21);
		panel_1.add(cb_find);
	}
	
	public void Clear()
	{
		((DefaultTableModel) table.getModel()).getDataVector().clear();
		((DefaultTableModel) table.getModel()).fireTableDataChanged();
		table.updateUI();
	}
	public void update()
	{
		/**
		 * ��ʾ��Ϣ
		 * 
		 * ������ˢ������б�
		 * 
		 * */
		Clear();
		 
		grades = service.getAllGrades();
		Iterator<Grades> it = grades.iterator();
		while (it.hasNext()) {
			Grades tempGrade = (Grades)it.next();
			
			studentNum = tempGrade.getStudentNum();
			StudentInformation tempStuInfo = service.getStuInfoByid(studentNum);
			studentName = tempStuInfo.getStudentName();
			classNum = tempStuInfo.getStudentClass();
			mathGrade = tempGrade.getMath();
			englishGrade = tempGrade.getEnglish();
			JAVAGrade = tempGrade.getJava();
			networkGrade = tempGrade.getComputerNetwork();
			totalGrade = Integer.parseInt(mathGrade)+Integer.parseInt(englishGrade)+Integer.parseInt(JAVAGrade)+Integer.parseInt(networkGrade);
			average = totalGrade/4;
			
			String sum = String.valueOf(totalGrade);
			String aver = String.valueOf(average);
			
			String sd[] = {studentNum,studentName,classNum,mathGrade,englishGrade,JAVAGrade,networkGrade,sum,aver};
			Vector temp = new Vector();
			for (int j = 0; j < sd.length; j++)
			{
				temp.add(sd[j]);
			}	
			dtm.addRow(temp);
		
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
