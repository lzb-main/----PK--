package ui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import service.ChangeGradeService;
import DAO.StudentInformation;
import DAO.StudentInformationDAO;

public class ChangeGrade extends JFrame {
	private JPanel contentPane;
	private JLabel StuNum;
	private JLabel classNum;
	private JTextField mathGrade;
	private JLabel StuName;
	private JTextField englishGrade;
	private JTextField JAVAGrade;
	private JTextField networkGrade;
	private StudentInformationDAO infoDao = new StudentInformationDAO();
	private ChangeGradeService service = new ChangeGradeService();
	
	public ChangeGrade(String studentNum) {
		
		StudentInformation tempInfo = infoDao.findById(studentNum);
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 230, 304);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		// contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		setTitle("������Ϣ");
		contentPane.setLayout(null);

		StuNum = new JLabel(tempInfo.getStudentNum());
		StuNum.setBounds(70, 20, 137, 21);
		contentPane.add(StuNum);
		//StuNum.setColumns(10);

	    mathGrade = new JTextField();
	    mathGrade.setColumns(10);
	    mathGrade.setBounds(70, 95, 137, 21);
		contentPane.add(mathGrade);
		
		classNum = new JLabel(tempInfo.getStudentClass());
		//classNum.setColumns(10);
		classNum.setBounds(70, 65, 137, 21);
		contentPane.add(classNum);

		StuName = new JLabel(tempInfo.getStudentName());
		//StuName.setColumns(10);
		StuName.setBounds(70, 42, 137, 21);
		contentPane.add(StuName);
		
		englishGrade = new JTextField();
		englishGrade.setColumns(10);
		englishGrade.setBounds(70, 122, 137, 21);
		contentPane.add(englishGrade);
		
		JAVAGrade = new JTextField();
		JAVAGrade.setColumns(10);
		JAVAGrade.setBounds(70, 147, 137, 21);
		contentPane.add(JAVAGrade);
		
		networkGrade = new JTextField();
		networkGrade.setColumns(10);
		networkGrade.setBounds(70, 173, 137, 21);
		contentPane.add(networkGrade);

		JLabel label = new JLabel("ѧ��");
		label.setBounds(15, 20, 54, 15);
		contentPane.add(label);

		JLabel label_2 = new JLabel("�༶");
		label_2.setBounds(15, 70, 54, 15);
		contentPane.add(label_2);

		JLabel psw_1 = new JLabel("����");
		psw_1.setBounds(15, 45, 54, 15);
		contentPane.add(psw_1);

		JLabel label_3 = new JLabel("��ѧ�ɼ�");
		label_3.setBounds(15, 98, 54, 15);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("Ӣ��ɼ�");
		label_4.setBounds(15, 125, 54, 15);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("JAVA�ɼ�");
		label_5.setBounds(15, 150, 54, 15);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("����ɼ�");
		label_6.setBounds(15, 175, 54, 15);
		contentPane.add(label_6);

		JButton btn_ok = new JButton("ȷ��");
		btn_ok.setBounds(41, 226, 70, 30);
		contentPane.add(btn_ok);

		btn_ok.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(service.changeInformation(StuNum.getText(), mathGrade.getText(), englishGrade.getText(), JAVAGrade.getText(), networkGrade.getText()))
				{
				    JOptionPane.showMessageDialog(null,"�޸���Ϣ�ɹ�","��ʾ",JOptionPane.OK_CANCEL_OPTION);
				    ChangeGrade.this.dispose();
				}
				else
				{
					JOptionPane.showMessageDialog(null,"�޸���Ϣʧ��","��ʾ",JOptionPane.OK_CANCEL_OPTION);
				}
			}
		});

		JButton btn_cancel = new JButton("ȡ��");
		btn_cancel.setBounds(121, 226, 70, 30);

		btn_cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ChangeGrade.this.dispose();
			}
		});
		contentPane.add(btn_cancel);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
