package service;

import javax.swing.JOptionPane;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;

import factory.HibernateSessionFactory;
import DAO.Grades;
import DAO.GradesDAO;
import DAO.StudentInformation;
import DAO.StudentInformationDAO;

public class AddInformationService {
	private StudentInformationDAO studetInfoDao;
	private GradesDAO gradeDao;
	private Session session;
	
	public AddInformationService()
	{
		session=HibernateSessionFactory.getSession();
		studetInfoDao = new StudentInformationDAO();
		gradeDao = new GradesDAO();
	}
	
	public boolean add(StudentInformation info, Grades gra) {
		try {
			studetInfoDao.save(info);
			gradeDao.save(gra);
		} catch (NonUniqueObjectException e) {
			// TODO: handle exception
			session.getTransaction().rollback();
			JOptionPane.showMessageDialog(null, "����ʧ��\n����Ѵ���", "��ʾ",
					JOptionPane.ERROR_MESSAGE);
			return false;
		} catch (NumberFormatException e) {
			// TODO: handle exception
			session.getTransaction().rollback();
			JOptionPane.showMessageDialog(null, "����ʧ��\n�����ʽ����", "��ʾ",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}

}
