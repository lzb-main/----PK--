package service;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import DAO.Grades;
import DAO.GradesDAO;
import DAO.StudentInformation;
import DAO.StudentInformationDAO;
import factory.HibernateSessionFactory;

public class MainUIService {
	private StudentInformationDAO studetInfoDao;
	private GradesDAO gradeDao;
	private Session session;
	public MainUIService()
	{
		session=HibernateSessionFactory.getSession();
		studetInfoDao = new StudentInformationDAO();
		gradeDao = new GradesDAO();
	}
	
	public List<Grades> getAllGrades()
	{
		session=HibernateSessionFactory.getSession();
		session.clear();
		List<Grades> grades = gradeDao.findAll();
		return grades;
	}
	
	public List<StudentInformation> getStuInfoByName(String studentName)
	{
		session.clear();
		List<StudentInformation> infoList = studetInfoDao.findByStudentName(studentName);
		return infoList;
	}
	
	public StudentInformation getStuInfoByid(String studentNum)
	{
		session.clear();
		StudentInformation stuInfo = studetInfoDao.findById(studentNum);
		return stuInfo;
	}
	
	public Grades getGradeById(String studentNum)
	{
		session.clear();
		Grades grade = gradeDao.findById(studentNum);
		return grade;
	}
	
	public boolean delete(String studentNum)
	{
		
		try
		 {
			StudentInformation tempInfo = studetInfoDao.findById(studentNum);
			Grades tempGrade = gradeDao.findById(studentNum);
			
			studetInfoDao.delete(tempInfo);
			gradeDao.delete(tempGrade);
		   
		    return true;
		 }
		 catch (Exception e) {
				
				e.printStackTrace();
				return false;
			}
	}

}
