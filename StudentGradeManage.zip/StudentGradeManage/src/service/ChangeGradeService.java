package service;

import org.hibernate.Session;
import org.hibernate.Transaction;

import factory.HibernateSessionFactory;
import DAO.Grades;
import DAO.GradesDAO;
import DAO.StudentInformationDAO;

public class ChangeGradeService {
	private StudentInformationDAO studetInfoDao;
	private GradesDAO gradeDao;
	private Session session;
	
	public ChangeGradeService()
	{
		session=HibernateSessionFactory.getSession();
		studetInfoDao = new StudentInformationDAO();
		gradeDao = new GradesDAO();
	}
	
	public boolean changeInformation(String stuNum, String math, String english, String JAVA, String network)
	{
		Transaction ta=session.beginTransaction();
		try {
			Grades grade = gradeDao.findById(stuNum);
			grade.setMath(math);
			grade.setEnglish(english);
			grade.setJava(JAVA);
			grade.setComputerNetwork(network);
			
			session.update(grade);
			ta.commit();
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			ta.rollback();
			return false;
		}
	}

}
