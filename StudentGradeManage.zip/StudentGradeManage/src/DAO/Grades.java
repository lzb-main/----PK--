package DAO;

/**
 * Grades entity. @author MyEclipse Persistence Tools
 */

public class Grades implements java.io.Serializable {

	// Fields

	private String studentNum;
	private String math;
	private String english;
	private String java;
	private String computerNetwork;

	// Constructors

	/** default constructor */
	public Grades() {
	}

	/** full constructor */
	public Grades(String studentNum, String math, String english, String java,
			String computerNetwork) {
		this.studentNum = studentNum;
		this.math = math;
		this.english = english;
		this.java = java;
		this.computerNetwork = computerNetwork;
	}

	// Property accessors

	public String getStudentNum() {
		return this.studentNum;
	}

	public void setStudentNum(String studentNum) {
		this.studentNum = studentNum;
	}

	public String getMath() {
		return this.math;
	}

	public void setMath(String math) {
		this.math = math;
	}

	public String getEnglish() {
		return this.english;
	}

	public void setEnglish(String english) {
		this.english = english;
	}

	public String getJava() {
		return this.java;
	}

	public void setJava(String java) {
		this.java = java;
	}

	public String getComputerNetwork() {
		return this.computerNetwork;
	}

	public void setComputerNetwork(String computerNetwork) {
		this.computerNetwork = computerNetwork;
	}

}