package DAO;

/**
 * StudentInformation entity. @author MyEclipse Persistence Tools
 */

public class StudentInformation implements java.io.Serializable {

	// Fields

	private String studentNum;
	private String studentName;
	private String studentClass;

	// Constructors

	/** default constructor */
	public StudentInformation() {
	}

	/** full constructor */
	public StudentInformation(String studentNum, String studentName,
			String studentClass) {
		this.studentNum = studentNum;
		this.studentName = studentName;
		this.studentClass = studentClass;
	}

	// Property accessors

	public String getStudentNum() {
		return this.studentNum;
	}

	public void setStudentNum(String studentNum) {
		this.studentNum = studentNum;
	}

	public String getStudentName() {
		return this.studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentClass() {
		return this.studentClass;
	}

	public void setStudentClass(String studentClass) {
		this.studentClass = studentClass;
	}

}